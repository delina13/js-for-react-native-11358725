# DCIT202 Mobile Application Development - Assignment 1

**Student ID:** 11358725

## Overview

This assignment involves creating JavaScript functions to manipulate arrays and generate user profiles. The tasks are divided into multiple parts, each building on the previous one.

## Tasks

### Task 1: Create `arrayManipulation.js` and Implement `processArray`

- **File:** `arrayManipulation.js`
- **Function:** `processArray`
- **Description:** 
  - This function takes an array of numbers as an argument.
  - It returns a new array where each even number is squared, and each odd number is tripled.



### Task 2: Add `formatArrayStrings` to `arrayManipulation.js` 

- **File:** `arrayManipulation.js` 
- **Function:** `formatArrayStringsDescription`
- **Description:** 
- This function takes two arrays as arguments: an array of strings and an array of numbers processed by processArray.
- It modifies each string based on its corresponding number: capitalizes the entire string if the number is even, and converts the string to lowercase if the number is odd.

### Task 3: Create `userInfo.js and Implement` `createUserProfiles` 

- **File:** `userInfo.js` 
- **Function:** `createUserProfiles`
- **Description:**
- This function takes an array of names and the array of modified names from Task 2.
- It returns an array of objects, each containing originalName, modifiedName, and id (auto-incremented starting from 1).


- This README file provides a comprehensive guide to understanding and using the functions defined in the assignment, with clear descriptions, and information on each task.
